// JavaScript to add interactivity for the Start Prediction button

// Get the Start Prediction button by its ID
const startPredictionButton = document.getElementById("startPredictionButton");

// Function to handle the button click
function handlePredictionClick() {
    // Show an alert or perform any desired action
    alert("Starting prediction...");

    // Here you can redirect to a prediction form or another page
    // window.location.href = "prediction-form.html"; // Uncomment and add URL if needed
}

// Add event listener for the button click
startPredictionButton.addEventListener("click", handlePredictionClick);
// JavaScript to handle prediction form submission

// Select the form element
const predictionForm = document.getElementById("predictionForm");

if (predictionForm) {
    predictionForm.addEventListener("submit", function(event) {
        event.preventDefault(); // Prevent page reload on submit

        // Gather form data
        const formData = new FormData(predictionForm);
        const data = {};
        formData.forEach((value, key) => {
            data[key] = value;
        });

        // Log data for now, or send to server in the future
        console.log("Submitted data:", data);
        alert("Form submitted successfully!");

        // You could add code to send this data to a backend server
    });
}
